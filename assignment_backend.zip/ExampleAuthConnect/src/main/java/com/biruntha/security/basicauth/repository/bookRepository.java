package com.biruntha.security.basicauth.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.biruntha.security.basicauth.models.book;


@Repository
public interface bookRepository extends MongoRepository<book, String>{
	
	@Query("{$or: [ { 'title': { $regex: ?0 , $options: 'i' } }, {'author':{ $regex: ?0, $options: 'i' } },{ 'isbn': { $regex:?0 , $options: 'i' } },{ 'language': { $regex:?0 , $options: 'i' } },{ 'genre': { $regex: ?0 , $options: 'i' } } ]}")
	Page<book> searchBook(Pageable pageable, String searchText);

}
