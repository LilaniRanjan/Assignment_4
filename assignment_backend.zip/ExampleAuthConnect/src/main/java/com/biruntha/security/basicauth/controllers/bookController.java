package com.biruntha.security.basicauth.controllers;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.biruntha.security.basicauth.models.book;
import com.biruntha.security.basicauth.services.bookService;



@CrossOrigin("*")
@RestController
@RequestMapping("/book")
public class bookController {
	
	@Autowired
	bookService bookservice;
	
	@PostMapping
	@PreAuthorize("hasRole('USER')")
	public ResponseEntity<book> createBook(@RequestBody book book) {
		return bookservice.createBook(book);
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<book> getBookById(@PathVariable String id) {
		return bookservice.getBookById(id);
	}
	
	@GetMapping
	public ResponseEntity<List<book>> getAllBooks(){
		return bookservice.getAllBooks();
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteBookById(@PathVariable String id) {
		return bookservice.deleteBookById(id);
	}
	
	@PutMapping("/{id}")
	public ResponseEntity<book> updateBookById(@RequestBody book book, @PathVariable String id) {
		return bookservice.updateBookById(id, book);
	}
	
	@GetMapping("/page")
    public ResponseEntity<Map<String, Object>> getAllBooksInPage(
    		@RequestParam(name = "pageNo", defaultValue = "0") int pageNo, 
    		@RequestParam(name = "pageSize", defaultValue = "2") int pageSize, 
    		@RequestParam(name = "sortBy", defaultValue = "id") String sortBy) {
		return bookservice.getAllBooksInPage(pageNo, pageSize, sortBy);
	}
	
	@GetMapping( params = {"pageNo", "pageSize", "sortBy", "searchText"})
    public ResponseEntity<Map<String, Object>> getSearchBook(
    		@RequestParam(name = "pageNo", defaultValue = "0") int pageNo, 
    		@RequestParam(name = "pageSize", defaultValue = "2") int pageSize, 
    		@RequestParam(name = "sortBy", defaultValue = "id") String sortBy,
    		@RequestParam String searchText
    		) {
		return bookservice.getSearchBook(pageNo, pageSize, sortBy, searchText);
	}
	

}
