package com.biruntha.security.basicauth.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.biruntha.security.basicauth.models.book;
import com.biruntha.security.basicauth.repository.bookRepository;




@Service
public class bookService {
	
	@Autowired
	bookRepository bookrepository;
	
	
	public ResponseEntity<book> createBook(book book) {
		try {
			book bok = bookrepository.insert(book);
			return new ResponseEntity<>(bok, HttpStatus.CREATED);
		}catch (Exception e) {
			return new ResponseEntity<> (HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	public ResponseEntity<book> getBookById(String id) {
		Optional<book> bok = bookrepository.findById(id) ;
		if(bok.isPresent()) {
			return new ResponseEntity<book>(bok.get(), HttpStatus.OK);
		}else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
	
	public ResponseEntity<List<book>> getAllBooks() {
		try {
		    List<book> book = new ArrayList<book>();
		
		    bookrepository.findAll().forEach(book::add);
		
		    if (book.isEmpty()) {
		      return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		    }
		
		    return new ResponseEntity<>(book, HttpStatus.OK);
		} catch (Exception e) {
		    return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	public ResponseEntity<String> deleteBookById(String id) {
		try {
			bookrepository.deleteById(id); 
			return new ResponseEntity<> ("Successfully deleted", HttpStatus.OK) ; 
		} catch (Exception e) {
			return new ResponseEntity<> (HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}
	
	public ResponseEntity<book> updateBookById(String id, book newBook) {
		Optional<book> oldBook= bookrepository.findById(id);
		if(oldBook.isPresent()) {
			book bok= oldBook.get();
			bok.setTitle(newBook.getTitle());
			bok.setAuthor(newBook.getAuthor());
			bok.setBookUrl(newBook.getBookUrl());
			bok.setIsbn(newBook.getIsbn());
			bok.setPrice(newBook.getPrice());
			bok.setLanguage(newBook.getLanguage());
			bok.setGenre(newBook.getGenre());
		
			return new ResponseEntity<> ((bookrepository.save(bok)), HttpStatus.OK);
		}else {
			return new ResponseEntity<> (HttpStatus.NOT_FOUND);
		}
	}
	
	public ResponseEntity<Map<String, Object>> getAllBooksInPage(int pageNo, int pageSize, String sortBy) {
		try {
			Map<String, Object> response = new HashMap<>();
		    Sort sort = Sort.by(sortBy);
			Pageable pageable = PageRequest.of(pageNo, pageSize, sort);
		    Page<book> page = bookrepository.findAll(pageable);
		    response.put("data", page.getContent());
		    response.put("Total no of pages", page.getTotalPages());
		    response.put("Total_No_Of_Elements", page.getTotalElements());
		    response.put("Current page no", page.getNumber());
		    
		    return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (Exception e) {
		    return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	public ResponseEntity<Map<String, Object>>  getSearchBook(int pageNo, int pageSize, String sortBy, String searchText) {
		try {
			Map<String, Object> response = new HashMap<>();
			Sort sort = Sort.by(sortBy);
			Pageable pageable = PageRequest.of(pageNo, pageSize, sort);
		    Page<book> page =bookrepository.searchBook( pageable, searchText);
		    response.put("data", page.getContent());
		    response.put("Total no of pages", page.getTotalPages());
		    response.put("Total no of elements", page.getTotalElements());
		    response.put("Current page no", page.getNumber());
		    
		    if (page.isEmpty()) {
		      return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		    }else {
		    return new ResponseEntity<>(response, HttpStatus.OK);
		    }
		
		} catch (Exception e) {
		    return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
