package com.biruntha.security.basicauth.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.biruntha.security.basicauth.models.User;
import com.biruntha.security.basicauth.repository.UserRepository;



@Service
public class UserService {
	
	@Autowired
	UserRepository userRep;
	
	@Autowired
	AuthenticationManager authenticationManager;
	
	@Autowired
	PasswordEncoder encoder;
	
	public ResponseEntity<User> createUser(User user) {
		try {
			User use = userRep.insert(user);
			return new ResponseEntity<>(use, HttpStatus.CREATED);
		}catch (Exception e) {
			return new ResponseEntity<> (HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	public ResponseEntity<List<User>> getAllUsers() {
		try {
			List<User> user = new ArrayList<User>();
			
			userRep.findAll().forEach(user::add);
			
			if (user.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
			
			return new ResponseEntity<>(user, HttpStatus.OK);
		}catch (Exception e) {
			// TODO: handle exception
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	public ResponseEntity<Optional<User>> getUserById(String id) {
		Optional<User> user = userRep.findById(id);
		
		if(user.isPresent()) {
			return new ResponseEntity<Optional<User>>(user,HttpStatus.OK);
		}
		return new ResponseEntity<Optional<User>>(HttpStatus.NOT_FOUND);
	}

	public ResponseEntity<User> updateUser(User user, String id) {
		Optional<User> oldUser = userRep.findById(id);
		if (oldUser.isPresent()) {
			User _user = oldUser.get();
			_user.setUsername(user.getUsername());
			_user.setPassword(encoder.encode(user.getPassword()));
			_user.setEmail(user.getEmail());
		    _user.setRoles(user.getRoles());

			return new ResponseEntity<> (userRep.save(_user),HttpStatus.OK);		
		}else {
			return new ResponseEntity<> (HttpStatus.NOT_FOUND);
		}
	}
	
	public ResponseEntity<User> deleteUser(String id) {
		Optional<User> user = userRep.findById(id);
		try {
			if(user.isPresent()) {
				userRep.deleteById(id);
				return new ResponseEntity<User>(HttpStatus.OK);
			}else {
				return new ResponseEntity<User>(HttpStatus.NOT_FOUND);
			}
		}catch (Exception e) {
			// TODO: handle exception
			return new ResponseEntity<User>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	public ResponseEntity<Map<String, Object>> getAllUserInPage(int pageNo, int pageSize, String sortBy) {
		 try {
	   		 Map<String, Object> response = new HashMap<>();
	   	 	Sort sort = Sort.by(sortBy);
	   		 Pageable pageable = PageRequest.of(pageNo, pageSize, sort);
	   	 	Page<User> page = userRep.findAll(pageable);
	   	 	response.put("data", page.getContent());
	   	 	response.put("Total no of pages", page.getTotalPages());
	   	 	response.put("Total_No_Of_Elements", page.getTotalElements());
	   	 	response.put("Current page no", page.getNumber());
	   		 
	   	 	return new ResponseEntity<>(response, HttpStatus.OK);
	   	 } catch (Exception e) {
	   	 	return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
	   	 }
	}
	
	public ResponseEntity<Map<String, Object>> getSearchUser(int pageNo, int pageSize, String sortBy,
			String searchText) {
		try {
			Map<String, Object> response = new HashMap<>();
			Sort sort = Sort.by(sortBy);
			Pageable pageable = PageRequest.of(pageNo, pageSize, sort);
		    Page<User> page = userRep.searchUser( pageable, searchText);
		    response.put("data", page.getContent());
		    response.put("Total no of pages", page.getTotalPages());
		    response.put("Total_No_Of_Elements", page.getTotalElements());
		    response.put("Current page no", page.getNumber());
		    
		    if (page.isEmpty()) {
		      return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		    }else {
		    return new ResponseEntity<>(response, HttpStatus.OK);
		    }
		
		} catch (Exception e) {
		    return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
