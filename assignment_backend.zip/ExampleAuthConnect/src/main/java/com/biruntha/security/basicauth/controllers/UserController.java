package com.biruntha.security.basicauth.controllers;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.biruntha.security.basicauth.models.ERole;
import com.biruntha.security.basicauth.models.Role;
import com.biruntha.security.basicauth.models.User;
import com.biruntha.security.basicauth.repository.RoleRepository;
import com.biruntha.security.basicauth.repository.UserRepository;
import com.biruntha.security.basicauth.services.UserService;



@CrossOrigin(origins = {"http://localhost:3000"})
@RestController
@RequestMapping("api/auth/user")
public class UserController {
	
	@Autowired
	UserService userService;
	
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	RoleRepository roleRepository;
	
	@PostMapping
	@PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity<User> createUser(@RequestBody User user) {
		return userService.createUser(user);
	}
	
	@GetMapping
	@PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity<List<User>> getAllUsers(){
		return userService.getAllUsers();
	}
	
	@GetMapping("/{id}")
	@PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity<Optional<User>> getUserById(@PathVariable String id){
		return userService.getUserById(id);
	}
	
	@DeleteMapping("/{id}")
	@PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity<User> deleteUserById(@PathVariable String id){
		return userService.deleteUser(id);
	}
	
	@PutMapping("/{id}")
	public ResponseEntity<User> updateUser(@RequestBody User user, @PathVariable String id) {
	
	Set<String> strRoles = user.getUpdateroles();
	Set<Role> roles = new HashSet<>();

	if (strRoles == null) {
		Role userRole = roleRepository.findByName(ERole.ROLE_USER)
				.orElseThrow(() -> new RuntimeException("Error: Role is not found."));
		roles.add(userRole);
	} else {
		strRoles.forEach(role -> {
			switch (role) {
			case "admin":
				Role adminRole = roleRepository.findByName(ERole.ROLE_ADMIN)
						.orElseThrow(() -> new RuntimeException("Error: Role is not found."));
				roles.add(adminRole);

				break;
			case "user":
				Role userRole = roleRepository.findByName(ERole.ROLE_USER)
						.orElseThrow(() -> new RuntimeException("Error: Role is not found."));
				roles.add(userRole);

				break;

			default:
				Role userRole2 = roleRepository.findByName(ERole.ROLE_USER)
						.orElseThrow(() -> new RuntimeException("Error: Role is not found."));
				roles.add(userRole2);
			}
		});
	}

	user.setRoles(roles);
	
	return userService.updateUser(user, id);
	
	}
	
	@GetMapping("/page")
	public ResponseEntity<Map<String, Object>> getAllUserInPage(
			@RequestParam(name = "pageNo", defaultValue = "0") int pageNo,
			@RequestParam(name = "pageSize", defaultValue = "2") int pageSize,
			@RequestParam(name = "sortBy", defaultValue = "id") String sortBy){
				return userService.getAllUserInPage(pageNo, pageSize, sortBy);
			}
	
	@GetMapping( params = {"pageNo", "pageSize", "sortBy", "searchText"})
    public ResponseEntity<Map<String, Object>> getSearchUser(
    		@RequestParam(name = "pageNo", defaultValue = "0") int pageNo, 
    		@RequestParam(name = "pageSize", defaultValue = "2") int pageSize, 
    		@RequestParam(name = "sortBy", defaultValue = "id") String sortBy,
    		@RequestParam String searchText
    		) {
		return userService.getSearchUser(pageNo, pageSize, sortBy, searchText);
	}

}
